const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
const dropdowns = document.querySelectorAll(".dropdown");

menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("show");
});

dropdowns.forEach((dropdown) => {
  const button = dropdown.querySelector(".dropbtn");
  button.addEventListener("click", (event) => {
    event.preventDefault();

    dropdowns.forEach((other) => {
      if (other !== dropdown) other.classList.remove("open");
    });

    dropdown.classList.toggle("open");
  });
});

document.addEventListener("click", (event) => {
  if (!event.target.closest(".navbar")) {
    dropdowns.forEach((dropdown) => dropdown.classList.remove("open"));
    navLinks.classList.remove("show");
  }
});

document.querySelectorAll(".nav-links a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("show");
    dropdowns.forEach((dropdown) => dropdown.classList.remove("open"));
  });
});
